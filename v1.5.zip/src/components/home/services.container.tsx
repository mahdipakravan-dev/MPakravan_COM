import { useTranslations } from 'next-intl'
import Services from './services'

function ServicesContainer() {
  
  return <Services />
}

export default ServicesContainer
