import ContactMeSection from './contact-me'

function ContactMeContainer() {
  return <ContactMeSection/>
}

export default ContactMeContainer
