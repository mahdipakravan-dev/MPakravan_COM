import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export const shineAnimation =
    'animate-shine bg-[linear-gradient(45deg,transparent_25%,rgba(68,68,68,.2)_50%,transparent_75%,transparent_100%)] bg-[length:250%_250%,100%_100%] bg-[position:-100%_0,0_0] bg-no-repeat'

export function randomInt(max : number) {
    return Math.floor(Math.random() * max);
}

export function makeImageUrl(collectionId: string, recordId: string, fileName: string) {
    return `https://api.mpakravan.com/api/files/${collectionId}/${recordId}/${fileName}`
}